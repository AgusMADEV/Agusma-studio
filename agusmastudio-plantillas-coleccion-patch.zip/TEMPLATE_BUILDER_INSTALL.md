# Collection templates + template sections

1. Importa `database/migrations/20260806_collection_template_sections.sql` en phpMyAdmin.
2. Copia los archivos del patch sobre la raiz del proyecto.
3. Entra en `admin/index.php#colecciones` y abre una coleccion que ya tenga secciones.
4. Pulsa **Guardar como plantilla**.
5. Entra en `admin/index.php#plantillas`, revisa la estructura y activa la plantilla.
6. Crea una nueva coleccion y selecciona esa plantilla en **Plantilla inicial**.

La plantilla solo se usa como punto de partida. Al crear la coleccion, sus filas se copian a `collection_sections`; editar o eliminar la plantilla posteriormente no modifica las colecciones existentes.

La migracion elimina la antigua capa `collection_template_variants` y las columnas `collections.template_variant_id` y `collections.template_config`. Haz una copia de seguridad de la base de datos antes de ejecutarla.
